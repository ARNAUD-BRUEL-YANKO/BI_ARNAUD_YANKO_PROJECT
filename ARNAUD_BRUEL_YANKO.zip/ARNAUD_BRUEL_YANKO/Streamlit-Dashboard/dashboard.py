import streamlit as st
import os

root = os.path.join(os.path.dirname(__file__))

dashboards = {
    "Données Brutes": os.path.join(root, "raw.py"),
    "Données Néttoyées et complétées": os.path.join(root, "cleaned.py"),
    "Map": os.path.join(root, "map.py"),
    "Statistiques": os.path.join(root, "stats.py"),
}
st.sidebar.image("data/bruel.png", caption="Par Arnaud Bruel Yanko K.", use_column_width=True)
choice = st.sidebar.selectbox("Choisir une page", list(dashboards.keys()))

path = dashboards[choice]
with open(path, encoding="utf-8") as code:
    exec(code.read(), globals())

st.sidebar.write("""
    Vous pouvez trouver les sources de ce dasboard sur mon [Github](https://github.com/ARNAUD-BRUEL-YANKO).
    """)
