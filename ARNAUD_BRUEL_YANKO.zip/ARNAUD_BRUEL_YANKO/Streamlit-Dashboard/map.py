from pathlib import Path
import pandas as pd
import streamlit as st
import numpy as np
import altair as alt

st.title('Analyse de mes données de Géolocalisation')
st.header('Map')

@st.cache
def load_data():
   positions_data_path = Path() / 'data/positions_cleaned_sample.csv'
   data = pd.read_csv(positions_data_path)
   return data
   

data_load_state = st.text('Chargement des données...')
df = load_data()
data_load_state.text("Données chargées avec cache activé !")

with st.container():
    st.subheader('Les lieux visités:')
    st.map(df)
    with st.expander("Voir explication..."):
        st.write("""
         La carte ci-dessus affiche les différents lieux (latitude, longitude) recueillis dans notre dataset. 
         Une projection et une transformation des données ont été néccéssaires pour arriver à ce résultat.
         La carte a été produite grâce à st.map().
        """)

