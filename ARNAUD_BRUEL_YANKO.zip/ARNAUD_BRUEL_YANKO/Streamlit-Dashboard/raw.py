from pathlib import Path
import pandas as pd
import streamlit as st
import numpy as np
import altair as alt
from st_aggrid import AgGrid, GridOptionsBuilder

st.title('Analyse de mes données de Géolocalisation')
st.header('Données brutes')

@st.cache
def load_data():
   positions_data_path = Path() / 'data/positions_raw_sample.csv'
   data = pd.read_csv(positions_data_path)
   return data
   

data_load_state = st.text('Chargement des données...')
df = load_data()
data_load_state.text("Données chargées avec cache activé !")

with st.container():
    col1, col2, col3 = st.columns(3)
    index = df.index
    number_of_rows = len(index)
    col1.metric(label="Nombre total de lignes", value=number_of_rows)

with st.container():
    st.subheader('Données affichées avec AgGrid:')
    available_themes = ["streamlit", "light", "dark", "blue", "fresh", "material"]
    selected_theme = st.selectbox("Theme", available_themes)
    gb = GridOptionsBuilder.from_dataframe(df)
    AgGrid(df,
        editable=True,
        gridOptions=gb.build(),
        data_return_mode="filtered_and_sorted",
        update_mode="no_update",
        theme=selected_theme)
    with st.expander("Voir explication..."):
        st.write("""
         Le tableau ci-dessus a été affiché en se servant de la bibliothèque AgGrid.
         Dans ce tableau, vous pouvez trier, filtrer, réordonner les éléments. Vous pouvez
         aussi choisir un thème d'affichage différent à appliquer sur le tableau. Que du bonheur !
        """)

