from pathlib import Path
import pandas as pd
import streamlit as st
import numpy as np
import altair as alt
import matplotlib.pyplot as plt
from pyecharts import options as opts
from pyecharts.charts import Bar
from streamlit_echarts import st_pyecharts

st.title('Analyse de mes données de Géolocalisation')
st.header('Statistiques')

@st.cache
def load_data():
   positions_data_path = Path() / 'data/positions_cleaned_sample.csv'
   data = pd.read_csv(positions_data_path)
   return data
   

data_load_state = st.text('Chargement des données...')
df = load_data()
data_load_state.text("Données chargées avec cache activé !")

with st.container():
    col1, col2, col3 = st.columns(3)
    city_count = df['city'].value_counts()
    col1.metric(label="Nombre de villes visitées", value=len(city_count.index))
    state_count = df['state'].value_counts()
    col2.metric(label="Nombre d'états visités", value=len(state_count.index))
    country_count = df['country'].value_counts()
    col3.metric(label="Nombre de pays visités", value=len(country_count.index))
    with st.expander("Voir explication..."):
        st.write("""
         Il faut noter ici, l'utilisation des colonnes st.columns(). Les données ont aussi été affichées grâce à la fonction
         col.metric().
        """)

st.subheader('Stats sur les données recoltées par ville, état et pays:')
with st.container():
    col1, col2, col3 = st.columns(3)
    with col1:
        st.caption('Nombre de lignes par ville:')
        city_count = df['city'].value_counts()
        x = city_count.index
        city_count_frame = city_count.to_frame()
        y = city_count_frame['city']
        fig, ax = plt.subplots()
        ax.bar(x, y)
        st.pyplot(fig)
    with col2:
        st.caption('Nombre de lignes par état:')
        state_count = df['state'].value_counts()
        x = state_count.index
        state_count_frame = state_count.to_frame()
        y = state_count_frame['state']
        fig, ax = plt.subplots()
        ax.bar(x, y)
        st.pyplot(fig)
    with col3:
        st.caption('Nombre de lignes par pays:')
        country_count = df['country'].value_counts()
        x = country_count.index
        country_count_frame = country_count.to_frame()
        y = country_count_frame['country']
        fig, ax = plt.subplots()
        ax.bar(x, y)
        st.pyplot(fig)
    with st.expander("Voir explication..."):
        st.write("""
         Les données des villes, états et pays ne sont pas dans le dataset, elles sont récupérées à partir des coordonnées
         grâce à la librairie geopy. Pour améliorer les performances, ces valeurs sont récupérées une fois, lors du néttoyage des données. st.pyplot() couplé à matplotlib, a servi à produire ces diagrammes.
        """)

st.subheader('Les villes visitées et le nombre de ligne faisant référence à celles-ci:')
with st.container():
    city_count = df['city'].value_counts()
    city_count_indexes_frame = city_count.index.to_frame()
    city_count_frame = city_count.to_frame()
    b = (
        Bar()
        .add_xaxis(city_count.index.tolist())
        .add_yaxis(
            "Nombre de lignes", city_count_frame['city'].tolist()
        )
    )
    st_pyecharts(b)
    with st.expander("Voir explication..."):
        st.write("""
            Avec cet autre diagramme, nous expérimentons le module pyecharts sur les villes visitées. La différence
            c'est que le diagramme est est plus lisible.
            """)


st.subheader('Stats sur les sources de capture:')
with st.container():
    col1, col2 = st.columns(2)
    with col1:
        source_count = df['source'].value_counts()
        x = source_count.index
        source_count_frame = source_count.to_frame()
        y = source_count_frame['source']
        fig, ax = plt.subplots()
        ax.pie(y, labels = x, autopct='%1.2f%%')
        ax.legend(title = "Sources:")
        st.pyplot(fig)
        with st.expander("Voir explication..."):
            st.write("""
                Pour ce premier diagramme, nous nous servi de st.pyplot() couplé à matplotlib comme précédemment,
                cependant, c'est un pie chart qui est affiché.
                """)
    with col2:
        source_count = df['source'].value_counts()
        source_count_indexes_frame = source_count.index.to_frame()
        source_count_indexes_frame = source_count_indexes_frame.rename(columns={0: 'Source'})
        source_count_frame = source_count.to_frame()
        source_count_frame = source_count_frame.rename(columns={'source': 'Nombre de captures'})
        source_data = pd.concat([source_count_indexes_frame, source_count_frame], axis=1)
        c = alt.Chart(source_data).mark_circle().encode(
            x='Source', y='Nombre de captures', size='Nombre de captures', color='Nombre de captures', tooltip=['Source', 'Nombre de captures'])
        st.altair_chart(c, use_container_width=True)
        with st.expander("Voir explication..."):
            st.write("""
                Pour ce deuxième diagramme, nous avons tenu à expérimenter st.altair_chart().
                """)

with st.container():
    source_count = df['source'].value_counts()
    source_count_indexes_frame = source_count.index.to_frame()
    source_count_frame = source_count.to_frame()
    b = (
        Bar()
        .add_xaxis(source_count.index.tolist())
        .add_yaxis(
            "Nombre de captures", source_count_frame['source'].tolist()
        )
    )
    st_pyecharts(b)
    with st.expander("Voir explication..."):
        st.write("""
            Avec cet autre diagramme, nous expérimentons le module pyecharts.
            """)