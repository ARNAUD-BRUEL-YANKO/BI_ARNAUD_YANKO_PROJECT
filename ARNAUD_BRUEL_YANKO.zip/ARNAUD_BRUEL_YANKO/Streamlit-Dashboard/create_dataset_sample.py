from pathlib import Path
import pandas as pd
from copy import deepcopy
import json
import os.path
from geopy.geocoders import Nominatim

geolocator = Nominatim(user_agent="geoapiExercises")

def getLocation(lat, lon):
    location = geolocator.reverse(str(lat)+","+str(lon))
    address = location.raw['address']
    return address

def getCity(address):
    return address.get('city', getState(address))

def getState(address):
    return address.get('state', getCountry(address))

def getCountry(address):
    return address.get('country', 'UNKNOW')

def create_dataset_sample(sampleSize):
    if (os.path.isfile('./data/Historique_des_positions.csv')):
        hist_positions_data_path = Path() / 'data/Historique_des_positions.csv'
        df = pd.read_csv(hist_positions_data_path)
        df = df.sample(n=sampleSize)
        positions_converted_data_path = Path() / 'data/positions_raw_sample.csv'
        df.to_csv(positions_converted_data_path, index = None)

        data = df[['latitudeE7', 'longitudeE7']]
        data = data.rename(columns={'latitudeE7': 'lat', 'longitudeE7': 'lon'})
        data = data.applymap(lambda x : x / 10000000)
        data['address'] = data.apply(lambda row : getLocation(row['lat'], row['lon']), axis = 1)
        data['city'] = data.apply(lambda row : getCity(row['address']), axis = 1)
        data['state'] = data.apply(lambda row : getState(row['address']), axis = 1)
        data['country'] = data.apply(lambda row : getCountry(row['address']), axis = 1)

        data = data[['lat', 'lon', 'city', 'state', 'country']]

        df = pd.concat([df[['timestampMs' , 'source']], data], axis=1, join="inner")
        df = df.drop_duplicates()
        positions_cleaned_converted_data_path = Path() / 'data/positions_cleaned_sample.csv'
        df.to_csv(positions_cleaned_converted_data_path, index = None)

create_dataset_sample(3000)
